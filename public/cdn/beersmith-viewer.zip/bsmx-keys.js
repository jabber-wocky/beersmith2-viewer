var xml_urls = {
  'recipes' : 'https://dl.dropboxusercontent.com/s/<key>/Recipe.bsmx?dl=1',
  'hops': 'https://dl.dropboxusercontent.com/s/<key>/Hops.bsmx?dl=1',
  'grains' : 'https://dl.dropboxusercontent.com/s/<key>/Grain.bsmx?dl=1',
  'yeasts' : 'https://dl.dropboxusercontent.com/s/<key>/Yeast.bsmx?dl=1'
};

var page_urls = {
	'index' : 'index.html',
	'ingredients' : 'ingredients.html',
	'recipe_details' : 'recipe-details.html',
	'recipes' : 'recipes.html',
	'setup' : 'setup.html'
};

$(document).ready(function(){
  beersmithViewerLoad(xml_urls);
});
